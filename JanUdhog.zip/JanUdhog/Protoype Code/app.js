// Initialize Firebase(2)
const config = {
  apiKey: "AIzaSyCYOGJhl-BmkRDPOqh0iWUgbmkBLLnM-aw",
  authDomain: "janudhyog.firebaseapp.com",
  databaseURL: "https://janudhyog.firebaseio.com",
  projectId: "janudhyog",
  storageBucket: "janudhyog.appspot.com",
  messagingSenderId: "1051415196540",
  appId: "1:1051415196540:web:fab8c90f39095fe37a2af9",
  measurementId: "G-HLBF75PSY8"
};
firebase.initializeApp(config);

//Reference for form collection(3)
let formMessage = firebase.database().ref('registrationform');

//listen for submit event//(1)
document
  .getElementById('registrationform')
  .addEventListener('submit', formSubmit);

//Submit form(1.2)
function formSubmit(e) {
  e.preventDefault();
  // Get Values from the DOM
  let name = document.querySelector('#name').value;
  let contactnumber = document.querySelector('#Contactnumber').value;
  let aadharnumber = document.querySelector('#aadharnumber').value;
  let gender = document.querySelector('#gender').value;
  let birthday = document.querySelector('#birthday').value;
  let permaddress = document.querySelector('#permaddress').value;
  let tempaddress = document.querySelector('#tempaddress').value;
  let job = document.querySelector('#job').value;
  let hindi = document.querySelector('#lang1').checked;
  let kannada = document.querySelector('#lang2').checked;
  let telugu = document.querySelector('#lang3').checked;
  let tamil = document.querySelector('#lang4').checked;
  let lang5 = document.querySelector('#lang5').checked;
  let account_details = document.querySelector('#account_details').value;
  let locality = document.querySelector('#Locality').value;
  let Masonry = document.querySelector('#skill1').checked;
  let loadliftinghelping = document.querySelector('#skill2').checked;
  let domestic_help = document.querySelector('#skill3').checked;
  let gardener = document.querySelector('#skill4').checked;
  let painting = document.querySelector('#skill5').checked;
  let carpentry = document.querySelector('#skill6').checked;
  let plumbing = document.querySelector('#skill7').checked;
  let electrical = document.querySelector('#skill8').checked;
  
  //send message values
  sendMessage(name, contactnumber, aadharnumber,gender,birthday,permaddress,tempaddress,job,hindi,kannada,telugu,tamil,lang5,account_details,locality,Masonry,loadliftinghelping,domestic_help,gardener,painting,carpentry,plumbing,electrical);

  //Show Alert Message(5)
  document.querySelector('.alert').style.display = 'block';

  //Hide Alert Message After Seven Seconds(6)
  setTimeout(function() {
    document.querySelector('.alert').style.display = 'none';
  }, 7000);

  //Form Reset After Submission(7)
  document.getElementById('registrationform').reset();
}

//Send Message to Firebase(4)

function sendMessage(name, contactnumber, aadharnumber,gender,birthday,permaddress,tempaddress,job,hindi,kannada,telugu,tamil,lang5,account_details,locality,Masonry,loadliftinghelping,domestic_help,gardener,painting,carpentry,plumbing,electrical) {
  let newFormMessage = formMessage.push();
  newFormMessage.set({
    name: name,
	contactnumber : contactnumber,
	aadharnumber : aadharnumber,
	gender : gender,
	birthday : birthday,
	permaddress : permaddress,
	tempaddress : tempaddress,
	job : job,
	hindi : hindi,
	kannada :kannada,
	telugu : telugu,
	tamil : tamil,
	lang5 : lang5,
	account_details :account_details,
	locality : locality,
	Masonry : Masonry,
	loadliftinghelping : loadliftinghelping,
	domestic_help : domestic_help,
	gardener : gardener,
	painting : painting,
	carpentry : carpentry,
	plumbing : plumbing,
	electrical : electrical
    
  });
}